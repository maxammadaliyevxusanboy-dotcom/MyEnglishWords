package uz.myenglishwords

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Word(val english: String, val uzbek: String, val learned: Boolean = false)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vocabulary", Context.MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadWords()
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFF202124.toInt())
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        root.addView(label(title, 25f, true))
        status = label("")
        root.addView(status)
    }

    private fun showHome() {
        base("MyEnglishWords")
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val count = prefs.getInt("count_$today", 0)
        status.text = "Jami so‘zlar: ${words.size}    Bugun qo‘shilgan: $count / 30"
        root.addView(button("➕ Yangi so‘z qo‘shish") { showAdd() })
        root.addView(button("📚 Lug‘atim") { showList() })
        root.addView(button("🧠 Takrorlash") { showReview() })
        root.addView(label("So‘zlar telefoningizda saqlanadi. Kunlik maqsad: 30 ta yangi so‘z.", 14f))
    }

    private fun showAdd() {
        base("Yangi so‘z qo‘shish")
        val english = EditText(this).apply { hint = "English word"; singleLine = true }
        val uzbek = EditText(this).apply { hint = "O‘zbekcha tarjimasi"; singleLine = true }
        root.addView(english); root.addView(uzbek)
        root.addView(button("Saqlash") {
            val en = english.text.toString().trim()
            val uz = uzbek.text.toString().trim()
            if (en.isBlank() || uz.isBlank()) {
                Toast.makeText(this, "Ikkala maydonni ham to‘ldiring", Toast.LENGTH_SHORT).show()
            } else if (words.any { it.english.equals(en, true) }) {
                Toast.makeText(this, "Bu so‘z lug‘atda bor", Toast.LENGTH_SHORT).show()
            } else {
                words.add(Word(en, uz))
                saveWords()
                val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                prefs.edit().putInt("count_$today", prefs.getInt("count_$today", 0) + 1).apply()
                Toast.makeText(this, "So‘z saqlandi", Toast.LENGTH_SHORT).show()
                showHome()
            }
        })
        root.addView(button("Orqaga") { showHome() })
    }

    private fun showList() {
        base("Lug‘atim (${words.size})")
        if (words.isEmpty()) root.addView(label("Hozircha so‘z yo‘q. Birinchi so‘zingizni qo‘shing."))
        words.forEachIndexed { i, w ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val t = TextView(this).apply {
                text = "${i + 1}. ${w.english} — ${w.uzbek}" + if (w.learned) " ✓" else ""
                textSize = 16f; setTextColor(0xFF202124.toInt()); setPadding(0, dp(8), dp(6), dp(8))
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "O‘chir"
                setOnClickListener { words.removeAt(i); saveWords(); showList() }
            })
            root.addView(row)
            val line = View(this).apply { setBackgroundColor(0xFFE0E0E0.toInt()) }
            root.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        }
        root.addView(button("Orqaga") { showHome() })
    }

    private var reviewIndex = 0
    private fun showReview() {
        if (words.isEmpty()) { base("Takrorlash"); root.addView(label("Avval lug‘atga so‘z qo‘shing.")); root.addView(button("Orqaga") { showHome() }); return }
        reviewIndex = reviewIndex.coerceIn(0, words.lastIndex)
        val w = words[reviewIndex]
        base("Takrorlash  ${reviewIndex + 1}/${words.size}")
        root.addView(label(w.english, 30f, true))
        val answer = TextView(this).apply { text = ""; textSize = 22f; setTextColor(0xFF176B3A.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20)) }
        root.addView(answer)
        root.addView(button("Tarjimani ko‘rsatish") { answer.text = w.uzbek })
        root.addView(button("Bilaman ✓") { words[reviewIndex] = w.copy(learned = true); saveWords(); nextReview() })
        root.addView(button("Yana takrorlayman") { nextReview() })
        root.addView(button("Orqaga") { showHome() })
    }

    private fun nextReview() { reviewIndex = (reviewIndex + 1) % words.size; showReview() }

    private fun saveWords() {
        val arr = JSONArray()
        words.forEach { arr.put(JSONObject().put("en", it.english).put("uz", it.uzbek).put("learned", it.learned)) }
        prefs.edit().putString("words", arr.toString()).apply()
    }

    private fun loadWords() {
        try {
            val arr = JSONArray(prefs.getString("words", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                words.add(Word(o.getString("en"), o.getString("uz"), o.optBoolean("learned", false)))
            }
        } catch (_: Exception) { }
    }
}
